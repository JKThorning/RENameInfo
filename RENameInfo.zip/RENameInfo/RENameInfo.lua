local splitToken = "#RE#"
local FullREString = splitToken
local knownREs = {}
local knownRanks = {}
local colorrare = {"ffffffffCommon","ff1eff00Uncommon", "ff0070ddRare", "ffa335eeEpic", "ffff8000Legendary"}
local getQualityColors = function(quality)
	quality = tonumber(quality)
	if quality == 1 then
		return 1, 1, 1
	elseif quality  == 2 then
		return 0.12, 1, 0
	elseif quality == 3 then
		return 0, 0.44, 0.87
	elseif quality == 4 then
		return 0.64, 0.21, 0.93
	elseif quality == 5 then
		return 1, 0.5, 0
	else
		return 0.4, 0.4, 0.4
	end
end
				
local function HexToRGBPerc(hex)
	local rhex, ghex, bhex = string.sub(hex, 1, 2), string.sub(hex, 3, 4), string.sub(hex, 5, 6)
	return tonumber(rhex, 16)/255, tonumber(ghex, 16)/255, tonumber(bhex, 16)/255
end
local f = CreateFrame("frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent",function(self,event,...)
	local t = 0
	print("Item Tooltip RE namer addon loaded.")
	self:UnregisterEvent(event)
	
	self:SetScript("OnUpdate",function(self,elapsed)
		t = t + elapsed
		if t > 5 then
			t = 0
			if AIO_REs then
				self:SetScript("OnUpdate",nil)
				print("AIO_REs found.")
				for k,v in pairs(AIO_REs) do 
					if type(v)=="table" then
						FullREString = FullREString..v[3]..": "..v[4]..splitToken
					end
				end
			else
				print("Attempted to create FullREString. AIO_REs is nil.")
			end
		end
	end)
	
	local tooltip = GameTooltip
	tooltip:HookScript("OnTooltipSetItem", function(tooltip, ...)
		if not AIO_REs then return end
		if not tooltip:GetItem() then return end
		for lineNr = 3,tooltip:NumLines() do
			local font = _G[tooltip:GetName().."TextLeft"..lineNr]
			local text,r,g,b = font:GetText(),font:GetTextColor()
			if text and text:match("Equip: ") then
				if knownREs[text] then 
					local r, g, b, a = font:GetTextColor()
					font:SetText(knownREs[text]) 
					font:SetWidth(300)
					font:SetTextColor(getQualityColors(knownRanks[text]))
					return
				end
				text = text:gsub("Equip: ","")
				local _, id, name, desc, rarity, icon
				for k,v in pairs(AIO_REs) do
					if type(v)=="table" then
						_, id, name, desc, rarity, icon = unpack(v)
						local REtext = v[4]
						if desc == text:gsub(" Does not stack.","") then
							local x = tonumber(rarity:match("%d"))
							x = strsub(colorrare[x],1,8)
							local newText = v[3]..": "..text
							font:SetText(newText)
							knownREs["Equip: "..text] = newText
							knownRanks["Equip: "..text] = v[5]:match("%d")
							font:SetWidth(300)
							font:SetTextColor(getQualityColors(v[5]:match("%d")))
							return
						elseif desc == text:gsub(" Does not stack.",""):gsub("seconds","sec") then
							local newText = v[3]..": "..text
							font:SetText(newText)
							knownREs["Equip: "..text] = newText
							knownRanks["Equip: "..text] = v[5]:match("%d")
							font:SetWidth(300)
							font:SetTextColor(getQualityColors(v[5]:match("%d")))
							return
						end
					end
				end
				knownREs["Equip: "..text] = newText
			end			
		end
	end)
end)
